
    <?php
        include 'AddOns/header.php';
    ?>
<style>
    body{
    background: black;
}
    
</style>
    <div>
        <nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark" >
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <a class="navbar-brand" href="index.php">
                    <img src="Photos/LogoV" alt="" width="50" height="44">
                    
                    </a>    
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                        <ul class="navbar-nav mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="index.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Adminstration.php">Admin</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Inventory.php">Inventory</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="PurchaseOrder.php">Purchase Orders</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="Data.php">Data</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="ContactsList.php">Contacts</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </div> 
</head>
<body>
    <div class="d-flex justify-content-center ">
        <img src="Photos/404.jpg" alt="" class="mt-4"></img>
    </div>
</body>
</html>