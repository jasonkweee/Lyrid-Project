<footer class="bg-dark text-white text-center py-3">
     <p>Venom Indonesia; 2024 Your Website. All rights reserved.</p>
 </footer>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
 </html>